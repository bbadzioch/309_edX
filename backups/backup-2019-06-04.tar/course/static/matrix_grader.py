
from math import *
import numpy as np

hello = "hello"

class CustomError(Exception):
  pass

def srt_2_array(s):
  try:
      a = eval("np.array(" + s + ").astype(float)")
  except Exception:
      raise CustomError("Invalid input")
  return a

def checker(atol, rtol):
    def check_answer(expect, ans):

        A_ans = srt_2_array(ans)
        A_exp = srt_2_array(expect)

        if A_ans.shape != A_exp.shape:
            return False
        if not np.allclose(A_ans, A_exp, atol= atol, rtol=rtol):
            return False
        else:
            return True
    return check_answer
