

class FormatError(Exception):
    pass
