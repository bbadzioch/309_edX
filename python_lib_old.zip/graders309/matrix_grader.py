
from math import *
import numpy as np
from string import ascii_letters

from graders309.exceptions import *
from graders309.helpers import *


def array_grader(atol, rtol, dtype=float):

    def check_answer(expect, ans):

        A_ans = srt_2_array(ans, dtype=dtype)
        A_exp = srt_2_array(expect, dtype=dtype)

        if A_ans.shape != A_exp.shape:
            return False
        if not np.allclose(A_ans, A_exp, atol= atol, rtol=rtol):
            return False
        else:
            return True

    return check_answer
